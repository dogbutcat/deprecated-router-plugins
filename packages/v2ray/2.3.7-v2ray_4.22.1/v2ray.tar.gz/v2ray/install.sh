#! /bin/sh
export KSROOT=/koolshare
source $KSROOT/scripts/base.sh
eval `dbus export v2ray`
alias echo_date='echo 【$(date +%Y年%m月%d日\ %X)】:'
fwlocal=`cat /etc/openwrt_release|grep DISTRIB_RELEASE|cut -d "'" -f 2|cut -d "V" -f 2`
checkversion=`versioncmp $fwlocal 2.30`

# 判断路由架构和平台
case $(uname -m) in
    armv7l)
        logger "本v2ray插件用于koolshare OpenWRT/LEDE x86_64固件平台，arm平台不能安装！！！"
        logger "退出v2ray安装！"
        exit 1
    ;;
    mips)
        logger "本v2ray插件用于koolshare OpenWRT/LEDE x86_64固件平台，mips平台不能安装！！！"
        logger "退出v2ray安装！"！
        exit 1
    ;;
    x86_64)
        fw867=`cat /etc/banner|grep fw867`
        if [ -d "/koolshare" ] && [ -n "$fw867" ];then
            logger "固件平台【koolshare OpenWRT/LEDE x86_64】符合安装要求，开始安装插件！"
        else
            logger "本v2ray插件用于koolshare OpenWRT/LEDE x86_64固件平台，其它x86_64固件平台不能安装！！！"
            logger "退出v2ray安装！"
            exit 1
        fi
    ;;
  *)
        logger "本v2ray插件用于koolshare OpenWRT/LEDE x86_64固件平台，其它平台不能安装！！！"
          logger "退出v2ray安装！"
        exit 1
    ;;
esac

#校验固件版本
logger "开始检测固件版本..."
version_local=`cat /etc/openwrt_release|grep DISTRIB_RELEASE|cut -d "'" -f 2|cut -d "V" -f 2`
check_version=`versioncmp $version_local 2.12`
if [ "$check_version" == "1" ];then
    logger "当前固件版本太低，不支持最新版插件，请将固件升级到2.12以上版本"
    logger "退出v2ray安装！"
    exit 1
else
    logger "检测通过，v2ray符合安装条件！"
fi

# 准备
logger "v2ray: 创建相关文件夹..."
mkdir -p $KSROOT/v2ray
mkdir -p $KSROOT/init.d

# 关闭ss
if [ "$v2ray_basic_enable" == "1" ];then
    logger "先关闭v2ray，保证文件更新成功!"
    # [ -f "$KSROOT/ss/ssstart.sh" ] && sh $KSROOT/ss/ssstart.sh stop
    kill `ps |grep v2ray|grep -v grep|awk '{print $1}'`
fi

#升级前先删除无关文件
logger "v2ray: 清可能存在的理旧文件..."
rm -rf $KSROOT/v2ray/* >/dev/null 2>&1
rm -rf $KSROOT/init.d/S99v2ray.sh >/dev/null 2>&1
rm -rf $KSROOT/scripts/v2ray_* >/dev/null 2>&1
rm -rf $KSROOT/webs/Module_v2ray.asp  >/dev/null 2>&1
rm -rf $KSROOT/webs/res/icon-v2ray*
[ -f "/koolshare/webs/files/v2ray.tar.gz" ] && rm -rf /koolshare/webs/files/v2ray.tar.gz

# 清理一些不用的设置
# sed -i '/v2ray_config/d' /etc/crontabs/root >/dev/null 2>&1

# 复制文件
cd /tmp
logger "v2ray: 复制安装包内的文件到路由器..."
# if [ "$checkversion" == "1" ]; then
#     logger "koolss: 安装旧版本插件..."
#     cp -rf /tmp/koolss/bin/cdns1 $KSROOT/bin/cdns
#     cp -rf /tmp/koolss/bin/chinadns1 $KSROOT/bin/chinadns
#     cp -rf /tmp/koolss/bin/dns2socks1 $KSROOT/bin/dns2socks
#     cp -rf /tmp/koolss/bin/ss-tunnel1 $KSROOT/bin/ss-tunnel
#     cp -rf /tmp/koolss/bin/ss-local1 $KSROOT/bin/ss-local
#     cp -rf /tmp/koolss/bin/ss-redir1 $KSROOT/bin/ss-redir
#     cp -rf /tmp/koolss/bin/ssr-local1 $KSROOT/bin/ssr-local
#     cp -rf /tmp/koolss/bin/ssr-redir1 $KSROOT/bin/ssr-redir
#     cp -rf /tmp/koolss/bin/Pcap_DNSProxy1 $KSROOT/bin/Pcap_DNSProxy
# else
#     logger "koolss: 安装新版插件..."
#     cp -rf /tmp/koolss/bin/cdns $KSROOT/bin/cdns
#     cp -rf /tmp/koolss/bin/chinadns $KSROOT/bin/chinadns
#     cp -rf /tmp/koolss/bin/dns2socks $KSROOT/bin/dns2socks
#     cp -rf /tmp/koolss/bin/ss-tunnel $KSROOT/bin/ss-tunnel
#     cp -rf /tmp/koolss/bin/ss-local $KSROOT/bin/ss-local
#     cp -rf /tmp/koolss/bin/ss-redir $KSROOT/bin/ss-redir
#     cp -rf /tmp/koolss/bin/ssr-local $KSROOT/bin/ssr-local
#     cp -rf /tmp/koolss/bin/ssr-redir $KSROOT/bin/ssr-redir
#     cp -rf /tmp/koolss/bin/Pcap_DNSProxy $KSROOT/bin/
# fi
cp -rf /tmp/v2ray/bin/v2ray $KSROOT/bin/
cp -rf /tmp/v2ray/bin/v2ctl $KSROOT/bin/
cp -rf /tmp/v2ray/v2ray/* $KSROOT/v2ray/
cp -rf /tmp/v2ray/scripts/* $KSROOT/scripts/
cp -rf /tmp/v2ray/init.d/* $KSROOT/init.d/
cp -rf /tmp/v2ray/webs/* $KSROOT/webs/
cp /tmp/v2ray/install.sh $KSROOT/scripts/v2ray_install.sh
cp /tmp/v2ray/uninstall.sh $KSROOT/scripts/uninstall_v2ray.sh

# delete luci cache
# rm -rf /tmp/luci-*

# 为新安装文件赋予执行权限...
logger "v2ray: 为新安装文件赋予执行权限..."
chmod 755 $KSROOT/bin/*
chmod 755 $KSROOT/scripts/v2ray_*
chmod 755 $KSROOT/init.d/S99v2ray.sh

# copy geoip data
cp -rf /tmp/v2ray/bin/geoip.dat $KSROOT/bin
cp -rf /tmp/v2ray/bin/geosite.dat $KSROOT/bin

# local_version=`cat $KSROOT/ss/version`
local_version="2.3.7"
logger "v2ray: 设置版本号为$local_version..."
dbus set v2ray_version=$local_version

sleep 1
logger "v2ray: 删除相关安装包..."
rm -rf /tmp/v2ray* >/dev/null 2>&1

logger "v2ray: 设置一些安装信息..."

#install new v2ray
dbus set softcenter_module_v2ray_description="模块化的代理软件包"
dbus set softcenter_module_v2ray_install=1
dbus set softcenter_module_v2ray_name=v2ray
dbus set softcenter_module_v2ray_title=V2Ray
dbus set softcenter_module_v2ray_version=$local_version

if [ "$v2ray_basic_enable" == "1" ];then
    logger "v2ray: 重启v2ray！"
    # sh $KSROOT/ss/ssstart.sh restart
    v2ray --config=$KSROOT/v2ray/v2ray.json 2>&1 &
fi

sleep 1
logger "v2ray: V2Ray插件安装完成..."

